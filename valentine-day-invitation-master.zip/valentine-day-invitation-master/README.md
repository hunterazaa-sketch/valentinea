<h2>❤️About the project❤️</h2>

  <p>A <b>Valentine Day Invitation</b> website is a website that help you to invite girl to Valentine's Day</p>
  <p>You're welcome </p>

  <br>

<h2>Steps: </h2>
1) 💓 Fork this project</p>
2) 💗 Change name in index.html</p>
3) 💝 Deploy project on github-pages</p>
